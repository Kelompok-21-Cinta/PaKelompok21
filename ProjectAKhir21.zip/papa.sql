-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2023 at 09:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `papa`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `kode_admin` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `wilayah_kerja` varchar(50) NOT NULL,
  `hak_akses` varchar(50) NOT NULL,
  `admin_kode_admin` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `kode_barang` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `jenis_barang` varchar(50) NOT NULL,
  `berat_barang` decimal(7,2) NOT NULL,
  `kategori_barang` varchar(50) NOT NULL,
  `estimasi_pengiriman` varchar(30) NOT NULL,
  `jenis_pengiriman` varchar(40) NOT NULL,
  `nama_penerima` varchar(50) NOT NULL,
  `alamat_penerima` varchar(100) NOT NULL,
  `pengguna_userid` int(11) NOT NULL,
  `biaya_pengiriman` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `biasa`
--

CREATE TABLE `biasa` (
  `kode_pengguna` int(11) NOT NULL,
  `poin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `data_transaksi`
--

CREATE TABLE `data_transaksi` (
  `kode_transaksi` int(11) NOT NULL,
  `tanggal_kirim` datetime NOT NULL,
  `tanggal_terima` datetime NOT NULL,
  `biaya_pengantaran` float NOT NULL,
  `status_pengiriman` varchar(50) NOT NULL,
  `barang_kode_barang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_transaksi`
--

INSERT INTO `data_transaksi` (`kode_transaksi`, `tanggal_kirim`, `tanggal_terima`, `biaya_pengantaran`, `status_pengiriman`, `barang_kode_barang`) VALUES
(11, '2023-11-03 20:19:37', '2023-11-03 20:19:37', 100000, 'Terkirim', 12);

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `userid` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_telpon` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `undangan` varchar(50) DEFAULT NULL,
  `admin_kode_admin` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `verifycode` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `alamat2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(10) UNSIGNED NOT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `VerifyCode` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `Email`, `Password`, `VerifyCode`, `Status`) VALUES
(2200, 'ASU', 'adityadinata647@gmail.com', '1234', '', 'Verified'),
(2201, '', '', '', '713058', ''),
(2202, '', '', '', '555310', ''),
(2203, 'adit', 'elha.smd.nf@gmail.com', '1234', '', 'Verified'),
(2204, '', '', '', '694709', ''),
(2205, 'aa', 'adityadinata40@gmail.com', '1234', '525886', ''),
(2206, '', '', '', '325566', '');

-- --------------------------------------------------------

--
-- Table structure for table `vip`
--

CREATE TABLE `vip` (
  `kode_pengguna` int(11) NOT NULL,
  `keuntungan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`kode_admin`),
  ADD KEY `admin_admin_fk` (`admin_kode_admin`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kode_barang`),
  ADD KEY `barang_pengguna_fk` (`pengguna_userid`);

--
-- Indexes for table `biasa`
--
ALTER TABLE `biasa`
  ADD PRIMARY KEY (`kode_pengguna`);

--
-- Indexes for table `data_transaksi`
--
ALTER TABLE `data_transaksi`
  ADD PRIMARY KEY (`kode_transaksi`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`userid`),
  ADD KEY `pengguna_admin_fk` (`admin_kode_admin`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `vip`
--
ALTER TABLE `vip`
  ADD PRIMARY KEY (`kode_pengguna`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2207;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_admin_fk` FOREIGN KEY (`admin_kode_admin`) REFERENCES `admin` (`kode_admin`);

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_pengguna_fk` FOREIGN KEY (`pengguna_userid`) REFERENCES `pengguna` (`userid`);

--
-- Constraints for table `biasa`
--
ALTER TABLE `biasa`
  ADD CONSTRAINT `biasa_pengguna_fk` FOREIGN KEY (`kode_pengguna`) REFERENCES `pengguna` (`userid`);

--
-- Constraints for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD CONSTRAINT `pengguna_admin_fk` FOREIGN KEY (`admin_kode_admin`) REFERENCES `admin` (`kode_admin`);

--
-- Constraints for table `vip`
--
ALTER TABLE `vip`
  ADD CONSTRAINT `vip_pengguna_fk` FOREIGN KEY (`kode_pengguna`) REFERENCES `pengguna` (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
