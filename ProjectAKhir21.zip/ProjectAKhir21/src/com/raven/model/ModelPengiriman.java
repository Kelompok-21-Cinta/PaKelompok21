///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package com.raven.model;
//
///**
// *
// * @author Aditya D
// */
//public class ModelPengiriman {
//    private int kodeTransaksi;
//    private Date tanggalKirim;
//    private Date tanggalTerima;
//    private int adminKodeAdmin;
//    private double biayaPengantaran;
//    private String statusPengiriman;
//    private int barangKodeBarang;
//
//    public ModelPengiriman(int kodeTransaksi, Date tanggalKirim, Date tanggalTerima, int adminKodeAdmin, double biayaPengantaran, String statusPengiriman, int barangKodeBarang) {
//        this.kodeTransaksi = kodeTransaksi;
//        this.tanggalKirim = tanggalKirim;
//        this.tanggalTerima = tanggalTerima;
//        this.adminKodeAdmin = adminKodeAdmin;
//        this.biayaPengantaran = biayaPengantaran;
//        this.statusPengiriman = statusPengiriman;
//        this.barangKodeBarang = barangKodeBarang;
//    }
//
//    public int getKodeTransaksi() {
//        return kodeTransaksi;
//    }
//
//    public void setKodeTransaksi(int kodeTransaksi) {
//        this.kodeTransaksi = kodeTransaksi;
//    }
//
//    public Date getTanggalKirim() {
//        return tanggalKirim;
//    }
//
//    public void setTanggalKirim(Date tanggalKirim) {
//        this.tanggalKirim = tanggalKirim;
//    }
//
//    public Date getTanggalTerima() {
//        return tanggalTerima;
//    }
//
//    public void setTanggalTerima(Date tanggalTerima) {
//        this.tanggalTerima = tanggalTerima;
//    }
//
//    public int getAdminKodeAdmin() {
//        return adminKodeAdmin;
//    }
//
//    public void setAdminKodeAdmin(int adminKodeAdmin) {
//        this.adminKodeAdmin = adminKodeAdmin;
//    }
//
//    public double getBiayaPengantaran() {
//        return biayaPengantaran;
//    }
//
//    public void setBiayaPengantaran(double biayaPengantaran) {
//        this.biayaPengantaran = biayaPengantaran;
//    }
//
//    public String getStatusPengiriman() {
//        return statusPengiriman;
//    }
//
//    public void setStatusPengiriman(String statusPengiriman) {
//        this.statusPengiriman = statusPengiriman;
//    }
//
//    public int getBarangKodeBarang() {
//        return barangKodeBarang;
//    }
//
//    public void setBarangKodeBarang(int barangKodeBarang) {
//        this.barangKodeBarang = barangKodeBarang;
//    }
//
//    public DataTransaksi() {
//    }
//}
//
//}
