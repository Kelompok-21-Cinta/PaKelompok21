/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.model;

/**
 *
 * @author Aditya D
 */
public class ModelPengiriman {
        private String namaBarang;
        private int jumlahBarang;
        private String jenisBarang;
        private double beratBarang;
        private String jenisPengiriman;
        private String estimasiPengiriman;
        private double biayaPengiriman;
        private String alamatKirim;

        // Buat constructor sesuai kebutuhan

        // Getter dan Setter untuk setiap atribut
        public String getNamaBarang() {
            return namaBarang;
        }

        public void setNamaBarang(String namaBarang) {
            this.namaBarang = namaBarang;
        }

        public int getJumlahBarang() {
            return jumlahBarang;
        }

        public void setJumlahBarang(int jumlahBarang) {
            this.jumlahBarang = jumlahBarang;
        }

        public String getJenisBarang() {
            return jenisBarang;
        }

        public void setJenisBarang(String jenisBarang) {
            this.jenisBarang = jenisBarang;
        }

        public double getBeratBarang() {
            return beratBarang;
        }

        public void setBeratBarang(double beratBarang) {
            this.beratBarang = beratBarang;
        }

        public String getJenisPengiriman() {
            return jenisPengiriman;
        }

        public void setJenisPengiriman(String jenisPengiriman) {
            this.jenisPengiriman = jenisPengiriman;
        }

        public String getEstimasiPengiriman() {
            return estimasiPengiriman;
        }

        public void setEstimasiPengiriman(String estimasiPengiriman) {
            this.estimasiPengiriman = estimasiPengiriman;
        }

        public double getBiayaPengiriman() {
            return biayaPengiriman;
        }

        public void setBiayaPengiriman(double biayaPengiriman) {
            this.biayaPengiriman = biayaPengiriman;
        }

        public String getAlamatKirim() {
            return alamatKirim;
        }

        public void setAlamatKirim(String alamatKirim) {
            this.alamatKirim = alamatKirim;
        }
    }


