-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2023 at 04:37 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pap`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `kode_admin` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `wilayah_kerja` varchar(50) NOT NULL,
  `hak_akses` varchar(50) NOT NULL,
  `admin_kode_admin` int(11) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`kode_admin`, `nama`, `wilayah_kerja`, `hak_akses`, `admin_kode_admin`, `username`, `password`, `email`) VALUES
(1199, 'Super Admin', 'Kalimantan', 'Semua', 1199, 'SSA', '12345', 'thejak123pasar@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `kode_barang` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `jenis_barang` varchar(50) NOT NULL,
  `berat_barang` decimal(7,2) NOT NULL,
  `jenis_pengiriman` varchar(40) NOT NULL,
  `estimasi_pengiriman` varchar(30) NOT NULL,
  `biaya_pengiriman` int(11) NOT NULL,
  `alamat_kirim` varchar(50) NOT NULL,
  `UserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kode_barang`, `nama_barang`, `jumlah_barang`, `jenis_barang`, `berat_barang`, `jenis_pengiriman`, `estimasi_pengiriman`, `biaya_pengiriman`, `alamat_kirim`, `UserID`) VALUES
(4401, 'ccc', 3, 'rr', 4.00, 'Reguler', '3 hari', 40000, 'ccc', NULL),
(4402, 'ccc', 3, 'rr', 5.00, 'Reguler', '3 hari', 50000, 'cccggg', NULL),
(4403, 'ff', 3, 'gg', 4.00, 'Reguler', '3 hari', 40000, 'ff', NULL),
(4404, 'cc', 5, 'rr', 4.00, 'Reguler', '3 hari', 40000, 'cc', NULL),
(4405, 'add', 2, 'dd', 4.00, 'Reguler', '3 hari', 40000, 'ddd', NULL),
(4406, 'ad', 2, 'ff', 3.00, 'Reguler', '3 hari', 30000, 'ddd', NULL),
(4407, 'www', 2, 'e', 4.00, 'Reguler', '3 hari', 40000, 'wwww', NULL),
(4408, 'makanan', 1, 'makanan', 5.00, 'Kargo', '5 hari', 25000, 'bandung', NULL),
(4409, 'makanan', 5, 'makanan', 5.00, 'Kargo', '5 hari', 25000, 'Bandung', NULL),
(4410, 'makanan', 5, 'makan', 5.00, 'Reguler', '3 hari', 20000, 'mojokerto', NULL),
(4411, 'makanan', 5, 'makanan', 5.00, 'Ekspress', '1 hari', 100000, 'Bandung', NULL),
(4412, 'Makanan', 1, 'Makanan', 5.00, 'Reguler', '3 hari', 20000, 'Biasa', NULL),
(4413, 'Makanan', 1, 'Makanan', 5.00, 'Reguler', '3 hari', 50000, 'Biasa', NULL),
(4414, 'Makanan', 1, 'Makanan', 5.00, 'Reguler', '3 hari', 20000, 'VIP', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `biasa`
--

CREATE TABLE `biasa` (
  `UserID` int(11) NOT NULL,
  `poin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `data_transaksi`
--

CREATE TABLE `data_transaksi` (
  `kode_transaksi` int(11) NOT NULL,
  `kode_admin` int(11) DEFAULT NULL,
  `kode_barang` int(11) DEFAULT NULL,
  `nama_pengirim` varchar(50) NOT NULL,
  `nama_penerima` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Terkirim'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_transaksi`
--

INSERT INTO `data_transaksi` (`kode_transaksi`, `kode_admin`, `kode_barang`, `nama_pengirim`, `nama_penerima`, `status`) VALUES
(7, 1199, 4413, 'Biasa', 'Biasa', 'Terkirim'),
(8, 1199, 4414, 'VIP', 'VIP', 'Terkirim');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(10) UNSIGNED NOT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `VerifyCode` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT '',
  `Alamat` varchar(255) DEFAULT NULL,
  `Undangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `Email`, `Password`, `VerifyCode`, `Status`, `Alamat`, `Undangan`) VALUES
(2238, 'adit', 'adityadinata647@gmail.com', '1234', '', 'Verified', 'jalan juanda', 'VIP'),
(2239, 'aku', 'adityadinata40@gmail.com', '1234', '', 'Verified', 'jalan mangku', 'Biasa');

-- --------------------------------------------------------

--
-- Table structure for table `vip`
--

CREATE TABLE `vip` (
  `UserID` int(11) NOT NULL,
  `keuntungan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`kode_admin`),
  ADD KEY `admin_admin_fk` (`admin_kode_admin`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kode_barang`),
  ADD KEY `barang_user_fk` (`UserID`);

--
-- Indexes for table `biasa`
--
ALTER TABLE `biasa`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `data_transaksi`
--
ALTER TABLE `data_transaksi`
  ADD PRIMARY KEY (`kode_transaksi`),
  ADD KEY `data_transaksi_admin_fk` (`kode_admin`),
  ADD KEY `data_transaksi_barang_fk` (`kode_barang`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `vip`
--
ALTER TABLE `vip`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_transaksi`
--
ALTER TABLE `data_transaksi`
  MODIFY `kode_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2240;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_admin_fk` FOREIGN KEY (`admin_kode_admin`) REFERENCES `admin` (`kode_admin`);

--
-- Constraints for table `data_transaksi`
--
ALTER TABLE `data_transaksi`
  ADD CONSTRAINT `data_transaksi_admin_fk` FOREIGN KEY (`kode_admin`) REFERENCES `admin` (`kode_admin`),
  ADD CONSTRAINT `data_transaksi_barang_fk` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
